message = "Hello Python world!"
print(message)

message = "Hello Python Crash Course world!"
print(message)
