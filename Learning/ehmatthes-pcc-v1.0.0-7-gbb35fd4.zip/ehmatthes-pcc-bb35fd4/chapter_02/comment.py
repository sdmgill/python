# Say hello to everyone.
print("Hello Python people!")
